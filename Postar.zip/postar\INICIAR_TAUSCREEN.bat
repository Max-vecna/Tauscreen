@echo off
setlocal
cd /d "%~dp0"

if not exist "%~dp0ThirdParty\FFmpeg\ffmpeg.exe" (
  echo Preparando componente de video FFmpeg LGPL na primeira execucao...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR_FFMPEG_LGPL.ps1"
  if errorlevel 1 (
    echo.
    echo Nao foi possivel preparar o FFmpeg. Verifique a conexao com a internet e tente novamente.
    pause
    exit /b 1
  )
)

start "" "%~dp0TauScreen.exe"
