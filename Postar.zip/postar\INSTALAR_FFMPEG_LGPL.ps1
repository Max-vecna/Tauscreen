$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = Join-Path $Root 'ThirdParty\FFmpeg'
$TargetFfmpeg = Join-Path $Target 'ffmpeg.exe'
$FileName = 'ffmpeg-n8.1-latest-win64-lgpl-8.1.zip'
$BaseRelease = 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest'
$DownloadUrl = "$BaseRelease/$FileName"
$ChecksumsUrl = "$BaseRelease/checksums.sha256"

function Test-FfmpegLgpl {
    param([Parameter(Mandatory=$true)][string]$Exe)
    if (-not (Test-Path $Exe)) { return $false }
    try {
        $BuildConf = (& $Exe -hide_banner -buildconf 2>&1 | Out-String)
        if ($LASTEXITCODE -ne 0) { return $false }
        if ($BuildConf -match '--enable-gpl' -or $BuildConf -match '--enable-nonfree') { return $false }
        if ($BuildConf -notmatch '--enable-version3') { return $false }

        $Encoders = (& $Exe -hide_banner -encoders 2>&1 | Out-String)
        if ($LASTEXITCODE -ne 0) { return $false }
        if ($Encoders -notmatch 'h264_mf') { return $false }
        if ($Encoders -match 'libx264' -or $Encoders -match 'libx265') { return $false }

        & $Exe -hide_banner -loglevel error -f lavfi -i 'color=c=black:s=64x64:r=1:d=0.1' -frames:v 1 -an -c:v h264_mf -rate_control quality -quality 75 -scenario archive -pix_fmt nv12 -f null -
        if ($LASTEXITCODE -ne 0) { return $false }
        return $true
    } catch { return $false }
}

if (Test-FfmpegLgpl -Exe $TargetFfmpeg) { exit 0 }

$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('TauScreen-FFmpeg-' + [Guid]::NewGuid().ToString('N'))
$ZipPath = Join-Path $TempRoot $FileName
$ChecksumsPath = Join-Path $TempRoot 'checksums.sha256'
$ExtractPath = Join-Path $TempRoot 'extract'

try {
    New-Item -ItemType Directory -Path $Target -Force | Out-Null
    New-Item -ItemType Directory -Path $ExtractPath -Force | Out-Null

    Write-Host 'Baixando FFmpeg LGPL diretamente de BtbN/FFmpeg-Builds...' -ForegroundColor Cyan
    Invoke-WebRequest -Uri $DownloadUrl -OutFile $ZipPath -UseBasicParsing

    try {
        Invoke-WebRequest -Uri $ChecksumsUrl -OutFile $ChecksumsPath -UseBasicParsing
    } catch {
        Write-Warning ('Nao foi possivel baixar o checksum publicado pelo fornecedor: ' + $_.Exception.Message)
    }

    if (Test-Path $ChecksumsPath) {
        $ExpectedLine = Get-Content $ChecksumsPath | Where-Object { $_ -match [regex]::Escape($FileName) } | Select-Object -First 1
        if ($ExpectedLine -and $ExpectedLine -match '^([0-9a-fA-F]{64})\s+\*?(.+)$') {
            $Expected = $Matches[1].ToLowerInvariant()
            $Actual = (Get-FileHash $ZipPath -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($Actual -ne $Expected) { throw "SHA-256 do pacote FFmpeg nao confere. Esperado: $Expected / obtido: $Actual" }
            Write-Host 'SHA-256 do pacote conferido.' -ForegroundColor Green
        } else {
            Write-Warning 'O arquivo de checksums do fornecedor nao trouxe a entrada esperada; a validacao funcional/licenca ainda sera executada.'
        }
    }

    Expand-Archive -Path $ZipPath -DestinationPath $ExtractPath -Force
    $Ffmpeg = Get-ChildItem -Path $ExtractPath -Filter 'ffmpeg.exe' -File -Recurse | Select-Object -First 1
    if (-not $Ffmpeg) { throw 'ffmpeg.exe nao encontrado no pacote.' }
    if (-not (Test-FfmpegLgpl -Exe $Ffmpeg.FullName)) { throw 'O build FFmpeg baixado nao passou na validacao LGPL/h264_mf.' }

    Copy-Item $Ffmpeg.FullName $TargetFfmpeg -Force

    $LicenseFiles = Get-ChildItem -Path $ExtractPath -File -Recurse | Where-Object { $_.Name -match '^(LICENSE|COPYING)(\.|$)' }
    $Seen = @{}
    foreach ($License in $LicenseFiles) {
        if (-not $Seen.ContainsKey($License.Name)) {
            Copy-Item $License.FullName (Join-Path $Target $License.Name) -Force
            $Seen[$License.Name] = $true
        }
    }

    $Version = (& $Ffmpeg.FullName -hide_banner -version 2>&1 | Out-String).Trim()
    $BuildConf = (& $Ffmpeg.FullName -hide_banner -buildconf 2>&1 | Out-String)
    $Hash = (Get-FileHash $Ffmpeg.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    @"
FFmpeg obtido diretamente pelo usuario
======================================
Fornecedor: https://github.com/BtbN/FFmpeg-Builds
Projeto: https://ffmpeg.org/
Pacote: $DownloadUrl
Data: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss K')
SHA-256 ffmpeg.exe: $Hash

Validado: sem --enable-gpl, sem --enable-nonfree, sem libx264/libx265, com h264_mf funcional.

$Version

$BuildConf
"@ | Set-Content -Path (Join-Path $Target 'BUILD_INFO.txt') -Encoding UTF8

    Write-Host 'FFmpeg preparado com sucesso.' -ForegroundColor Green
}
finally {
    Remove-Item $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
}
