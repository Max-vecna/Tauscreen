@echo off
setlocal
cd /d "%~dp0"
title TauScreen - Preparando FFmpeg

echo ==============================================
echo   TauScreen - Preparacao automatica do FFmpeg
echo ==============================================
echo.
echo Esta janela pode ser acompanhada enquanto o TauScreen instala o FFmpeg.
echo Nao feche a janela durante o download.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR_FFMPEG_LGPL.ps1" -ProgressFile "%~1"
set "TAU_EXIT=%errorlevel%"

echo.
if "%TAU_EXIT%"=="0" (
    echo FFmpeg concluido. Esta janela sera fechada automaticamente.
    timeout /t 1 /nobreak ^>nul
) else (
    echo Falha ao preparar o FFmpeg. O TauScreen mostrara os detalhes.
    timeout /t 5 /nobreak ^>nul
)
exit /b %TAU_EXIT%
