﻿param(
    [string]$ProgressFile = ''
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = Join-Path $Root 'ThirdParty\FFmpeg'
$TargetFfmpeg = Join-Path $Target 'ffmpeg.exe'
$FileName = 'ffmpeg-n8.1-latest-win64-lgpl-8.1.zip'
$BaseRelease = 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest'
$DownloadUrl = "$BaseRelease/$FileName"
$ChecksumsUrl = "$BaseRelease/checksums.sha256"

function Set-TauProgress {
    param(
        [Parameter(Mandatory=$true)][int]$Percent,
        [Parameter(Mandatory=$true)][string]$Message
    )

    $Percent = [Math]::Max(0, [Math]::Min(100, $Percent))
    Write-Progress -Activity 'TauScreen - Preparando FFmpeg' -Status $Message -PercentComplete $Percent
    Write-Host (("[{0,3}%] {1}" -f $Percent, $Message)) -ForegroundColor Cyan

    if (-not [string]::IsNullOrWhiteSpace($ProgressFile)) {
        try {
            $parent = Split-Path -Parent $ProgressFile
            if ($parent -and -not (Test-Path $parent)) {
                New-Item -ItemType Directory -Path $parent -Force | Out-Null
            }
            [System.IO.File]::WriteAllText($ProgressFile, "$Percent|$Message", [System.Text.Encoding]::UTF8)
        } catch {
            # O arquivo serve apenas para atualizar a splash. Uma falha nele nao
            # deve interromper a instalacao do FFmpeg.
        }
    }
}

function Invoke-DownloadWithProgress {
    param(
        [Parameter(Mandatory=$true)][string]$Uri,
        [Parameter(Mandatory=$true)][string]$Destination,
        [int]$StartPercent = 15,
        [int]$EndPercent = 65,
        [string]$Label = 'Baixando arquivo...'
    )

    Add-Type -AssemblyName System.Net.Http
    $client = [System.Net.Http.HttpClient]::new()
    $response = $null
    $input = $null
    $output = $null
    try {
        $client.DefaultRequestHeaders.UserAgent.ParseAdd('TauScreen/1.0')
        $response = $client.GetAsync($Uri, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
        $response.EnsureSuccessStatusCode()

        $total = $response.Content.Headers.ContentLength
        $input = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
        $output = [System.IO.File]::Open($Destination, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        $buffer = New-Object byte[] (1024 * 1024)
        [long]$received = 0
        $lastReported = -1

        while (($read = $input.Read($buffer, 0, $buffer.Length)) -gt 0) {
            $output.Write($buffer, 0, $read)
            $received += $read

            if ($total -and $total -gt 0) {
                $fraction = [Math]::Min(1.0, $received / [double]$total)
                $percent = [int][Math]::Floor($StartPercent + (($EndPercent - $StartPercent) * $fraction))
                if ($percent -ne $lastReported) {
                    $mbNow = [Math]::Round($received / 1MB, 1)
                    $mbTotal = [Math]::Round($total / 1MB, 1)
                    Set-TauProgress $percent "$Label $mbNow MB / $mbTotal MB"
                    $lastReported = $percent
                }
            }
        }

        if (-not $total) {
            Set-TauProgress $EndPercent $Label
        }
    }
    finally {
        if ($output) { $output.Dispose() }
        if ($input) { $input.Dispose() }
        if ($response) { $response.Dispose() }
        $client.Dispose()
    }
}

function Test-FfmpegLgpl {
    param([Parameter(Mandatory=$true)][string]$Exe)
    if (-not (Test-Path $Exe)) { return $false }
    try {
        $BuildConf = (& $Exe -hide_banner -buildconf 2>&1 | Out-String)
        if ($LASTEXITCODE -ne 0) { return $false }
        if ($BuildConf -match '--enable-gpl' -or $BuildConf -match '--enable-nonfree') { return $false }
        if ($BuildConf -notmatch '--enable-version3') { return $false }

        $Encoders = (& $Exe -hide_banner -encoders 2>&1 | Out-String)
        if ($LASTEXITCODE -ne 0) { return $false }
        if ($Encoders -notmatch 'h264_mf') { return $false }
        if ($Encoders -match 'libx264' -or $Encoders -match 'libx265') { return $false }

        & $Exe -hide_banner -loglevel error -f lavfi -i 'color=c=black:s=64x64:r=1:d=0.1' -frames:v 1 -an -c:v h264_mf -rate_control quality -quality 75 -scenario archive -pix_fmt nv12 -f null -
        if ($LASTEXITCODE -ne 0) { return $false }
        return $true
    } catch { return $false }
}

Set-TauProgress 10 'Verificando instalacao atual do FFmpeg...'
New-Item -ItemType Directory -Path $Target -Force | Out-Null
if (Test-FfmpegLgpl -Exe $TargetFfmpeg) {
    Set-TauProgress 100 'FFmpeg ja esta instalado e validado.'
    Write-Progress -Activity 'TauScreen - Preparando FFmpeg' -Completed
    exit 0
}

$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('TauScreen-FFmpeg-' + [Guid]::NewGuid().ToString('N'))
$ZipPath = Join-Path $TempRoot $FileName
$ChecksumsPath = Join-Path $TempRoot 'checksums.sha256'
$ExtractPath = Join-Path $TempRoot 'extract'

try {
    Set-TauProgress 10 'Preparando pastas temporarias...'
    New-Item -ItemType Directory -Path $Target -Force | Out-Null
    New-Item -ItemType Directory -Path $ExtractPath -Force | Out-Null

    Set-TauProgress 15 'Iniciando download do FFmpeg LGPL...'
    Invoke-DownloadWithProgress -Uri $DownloadUrl -Destination $ZipPath -StartPercent 15 -EndPercent 65 -Label 'Baixando FFmpeg:'

    Set-TauProgress 67 'Baixando informacoes de integridade...'
    try {
        Invoke-WebRequest -Uri $ChecksumsUrl -OutFile $ChecksumsPath -UseBasicParsing
    } catch {
        Write-Warning ('Nao foi possivel baixar o checksum publicado pelo fornecedor: ' + $_.Exception.Message)
    }

    Set-TauProgress 70 'Verificando integridade do pacote...'
    if (Test-Path $ChecksumsPath) {
        $ExpectedLine = Get-Content $ChecksumsPath | Where-Object { $_ -match [regex]::Escape($FileName) } | Select-Object -First 1
        if ($ExpectedLine -and $ExpectedLine -match '^([0-9a-fA-F]{64})\s+\*?(.+)$') {
            $Expected = $Matches[1].ToLowerInvariant()
            $Actual = (Get-FileHash $ZipPath -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($Actual -ne $Expected) { throw "SHA-256 do pacote FFmpeg nao confere. Esperado: $Expected / obtido: $Actual" }
            Write-Host 'SHA-256 do pacote conferido.' -ForegroundColor Green
        } else {
            Write-Warning 'O arquivo de checksums nao trouxe a entrada esperada; a validacao funcional/licenca ainda sera executada.'
        }
    }

    Set-TauProgress 76 'Extraindo FFmpeg...'
    Expand-Archive -Path $ZipPath -DestinationPath $ExtractPath -Force
    $Ffmpeg = Get-ChildItem -Path $ExtractPath -Filter 'ffmpeg.exe' -File -Recurse | Select-Object -First 1
    if (-not $Ffmpeg) { throw 'ffmpeg.exe nao encontrado no pacote.' }

    Set-TauProgress 84 'Validando FFmpeg e encoder de video...'
    if (-not (Test-FfmpegLgpl -Exe $Ffmpeg.FullName)) { throw 'O build FFmpeg baixado nao passou na validacao LGPL/h264_mf.' }

    Set-TauProgress 91 'Instalando FFmpeg no TauScreen...'
    Copy-Item $Ffmpeg.FullName $TargetFfmpeg -Force

    $LicenseFiles = Get-ChildItem -Path $ExtractPath -File -Recurse | Where-Object { $_.Name -match '^(LICENSE|COPYING)(\.|$)' }
    $Seen = @{}
    foreach ($License in $LicenseFiles) {
        if (-not $Seen.ContainsKey($License.Name)) {
            Copy-Item $License.FullName (Join-Path $Target $License.Name) -Force
            $Seen[$License.Name] = $true
        }
    }

    Set-TauProgress 96 'Finalizando informacoes do FFmpeg...'
    $Version = (& $Ffmpeg.FullName -hide_banner -version 2>&1 | Out-String).Trim()
    $BuildConf = (& $Ffmpeg.FullName -hide_banner -buildconf 2>&1 | Out-String)
    $Hash = (Get-FileHash $Ffmpeg.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    @"
FFmpeg obtido diretamente pelo usuario
======================================
Fornecedor: https://github.com/BtbN/FFmpeg-Builds
Projeto: https://ffmpeg.org/
Pacote: $DownloadUrl
Data: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss K')
SHA-256 ffmpeg.exe: $Hash

Validado: sem --enable-gpl, sem --enable-nonfree, sem libx264/libx265, com h264_mf funcional.

$Version

$BuildConf
"@ | Set-Content -Path (Join-Path $Target 'BUILD_INFO.txt') -Encoding UTF8

    Set-TauProgress 100 'FFmpeg preparado com sucesso.'
    Write-Progress -Activity 'TauScreen - Preparando FFmpeg' -Completed
    Write-Host ''
    Write-Host 'FFmpeg preparado com sucesso. O TauScreen continuara automaticamente.' -ForegroundColor Green
}
catch {
    $msg = $_.Exception.Message
    Set-TauProgress 99 ("Falha ao preparar FFmpeg: " + $msg)
    Write-Host ''
    Write-Host ('ERRO: ' + $msg) -ForegroundColor Red
    throw
}
finally {
    Remove-Item $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
}
